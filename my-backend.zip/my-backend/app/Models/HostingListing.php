<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HostingListing extends Model
{
    use HasFactory;

    // The table associated with the model.
    protected $table = 'hosting_listings';

    // The attributes that are mass assignable.
    protected $fillable = [
        'host_name',
        'address',
        'home_description',
        'max_guests',
        'amenities',
        'additional_details',
        'is_available',
    ];

    // The attributes that should be cast to native types.
    protected $casts = [
        'is_available' => 'boolean',
    ];
}
