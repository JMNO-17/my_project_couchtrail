<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\HostingListing;
use Illuminate\Http\Request;

class HostingListingController extends Controller
{
    // Show all listings
    public function index()
    {
        $listings = HostingListing::all();
        return response()->json($listings);
    }

    // Show a single listing
    public function show($id)
    {
        $listing = HostingListing::findOrFail($id);
        return response()->json($listing);
    }

    // Create a new listing
    public function store(Request $request)
    {
        $request->validate([
            'host_name' => 'required',
            'address' => 'required',
            'home_description' => 'required',
            'max_guests' => 'required|numeric',
            'amenities' => 'required',
            'additional_details' => 'required',
            'is_available' => 'required|boolean',

        ]);

        $listing = HostingListing::create($request->all());
        return response()->json($listing, 201);
    }

    // Update a listing
    public function update(Request $request, $id)
    {
        $listing = HostingListing::findOrFail($id);
        $listing->update($request->all());
        return response()->json($listing);
    }

    // Delete a listing
    public function destroy($id)
    {
        $listing = HostingListing::findOrFail($id);
        $listing->delete();
        return response()->json(null, 204);
    }
}
