<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Host;
use App\Models\HostingListing;
use App\Models\Traveler;

class HostController extends Controller
{

    public function index()
    {
        $hosts = HostingListing::get();
        return response()->json($hosts);
    }

    public function store(Request $request)
    {
        $user = auth()->guard('api')->user();

        if (!$user) {
            return response()->json(['error' => 'Unauthenticated'], 401);
        }

        // Step 1: Remove traveler record (if exists)
        Traveler::where('user_id', $user->id)->delete();

        // Step 2: Create or update 'hosts' table
        $host = Host::firstOrCreate(
            ['user_id' => $user->id],
            [
                'location' => $request->location,
                'avatar' => $user->avatar ?? null,
                'rating' => 0,
                'review_count' => 0,
                'description' => $request->description,
                'home_description' => $request->home_description,
                'amenities' => $request->amenities,
                'is_verified' => false,
                'response_time' => '< 1 hour',
                'is_available' => true,
            ]
        );

        // Step 3: Create 'hosting_listings' entry
        HostingListing::create([
            'user_id' => $user->id,
            'host_id' => $host->id,
            'address' => $request->address,
            'home_description' => $request->home_description,
            'max_guests' => $request->max_guests,
            'amenities' => $request->amenities,
            'additional_details' => $request->additional_details,
            'is_available' => $request->is_available ?? true,
        ]);

        return response()->json(['message' => 'Host and listing created successfully']);
    }
}
